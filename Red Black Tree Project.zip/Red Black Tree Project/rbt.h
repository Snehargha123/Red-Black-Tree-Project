#ifndef RBT_H
#define RBT_H

#include <stdio.h>
#include <stdlib.h>

/* Data type */
typedef int data_t;

/* Node color */
typedef enum
{
    RED,
    BLACK
} color_t;

/* Red-Black Tree node */
typedef struct node
{
    data_t data;

    color_t color;

    struct node *left;
    struct node *right;
    struct node *parent;

} tree_t;


/* Return status */
#define SUCCESS 1
#define FAILURE 0


/* Red-Black Tree operations */

int insert(tree_t **root, data_t item);

int delete(tree_t **root, data_t item);

int search(tree_t **root, data_t item);

int find_minimum(tree_t **root, data_t *min);

int find_maximum(tree_t **root, data_t *max);

int delete_minimum(tree_t **root);

int delete_maximum(tree_t **root);


/* Display functions */

void display(tree_t *root);

void inorder(tree_t *root);

void preorder(tree_t *root);


/* Free memory */

void free_tree(tree_t **root);

#endif