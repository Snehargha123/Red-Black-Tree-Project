#include "rbt.h"


static void menu(void)
{
    printf("\n");
    printf("=================================\n");
    printf("        RED BLACK TREE\n");
    printf("=================================\n");

    printf("1. Insert\n");
    printf("2. Display\n");
    printf("3. Search\n");
    printf("4. Find Minimum\n");
    printf("5. Find Maximum\n");
    printf("6. Delete Node\n");
    printf("7. Delete Minimum\n");
    printf("8. Delete Maximum\n");
    printf("9. Inorder\n");
    printf("10. Preorder\n");
    printf("11. Exit\n");

    printf("=================================\n");
}


int main(void)
{
    tree_t *root = NULL;

    int choice;
    int item;
    int value;


    while (1)
    {
        menu();

        printf("Enter choice: ");
        scanf("%d", &choice);


        switch (choice)
        {
            case 1:

                printf("Enter element: ");
                scanf("%d", &item);

                if (insert(&root, item))
                {
                    printf("Element inserted successfully.\n");
                }
                else
                {
                    printf("Insertion failed / duplicate element.\n");
                }

                break;


            case 2:

                printf("\nRed Black Tree:\n");

                display(root);

                break;


            case 3:

                printf("Enter element to search: ");
                scanf("%d", &item);

                if (search(&root, item))
                {
                    printf("Element %d found.\n", item);
                }
                else
                {
                    printf("Element %d not found.\n", item);
                }

                break;


            case 4:

                if (find_minimum(&root, &value))
                {
                    printf("Minimum = %d\n", value);
                }
                else
                {
                    printf("Tree is empty.\n");
                }

                break;


            case 5:

                if (find_maximum(&root, &value))
                {
                    printf("Maximum = %d\n", value);
                }
                else
                {
                    printf("Tree is empty.\n");
                }

                break;


            case 6:

                printf("Enter element to delete: ");
                scanf("%d", &item);

                if (delete(&root, item))
                {
                    printf("Element deleted successfully.\n");
                }
                else
                {
                    printf("Element not found.\n");
                }

                break;


            case 7:

                if (delete_minimum(&root))
                {
                    printf("Minimum element deleted.\n");
                }
                else
                {
                    printf("Tree is empty.\n");
                }

                break;


            case 8:

                if (delete_maximum(&root))
                {
                    printf("Maximum element deleted.\n");
                }
                else
                {
                    printf("Tree is empty.\n");
                }

                break;


            case 9:

                printf("Inorder: ");

                inorder(root);

                printf("\n");

                break;


            case 10:

                printf("Preorder: ");

                preorder(root);

                printf("\n");

                break;


            case 11:

                free_tree(&root);

                printf("Program terminated.\n");

                return 0;


            default:

                printf("Invalid choice.\n");
        }
    }

    return 0;
}