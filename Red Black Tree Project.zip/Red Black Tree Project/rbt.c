#include "rbt.h"

static tree_t nil_node;
static tree_t *NIL = &nil_node;
static int initialized = 0;


/* Initialize NIL */

static void init_nil(void)
{
    if (!initialized)
    {
        NIL->data = 0;
        NIL->color = BLACK;
        NIL->left = NIL;
        NIL->right = NIL;
        NIL->parent = NIL;

        initialized = 1;
    }
}


/* Check empty */

static int is_empty(tree_t *root)
{
    return root == NULL || root == NIL;
}


/* Create node */

static tree_t *create_node(data_t item)
{
    tree_t *new_node;

    new_node = malloc(sizeof(tree_t));

    if (new_node == NULL)
    {
        return NULL;
    }

    new_node->data = item;
    new_node->color = RED;

    new_node->left = NIL;
    new_node->right = NIL;
    new_node->parent = NIL;

    return new_node;
}


/* Left rotation */

static void left_rotate(tree_t **root, tree_t *x)
{
    tree_t *y;

    y = x->right;

    x->right = y->left;

    if (y->left != NIL)
    {
        y->left->parent = x;
    }

    y->parent = x->parent;

    if (x->parent == NIL)
    {
        *root = y;
    }
    else if (x == x->parent->left)
    {
        x->parent->left = y;
    }
    else
    {
        x->parent->right = y;
    }

    y->left = x;
    x->parent = y;
}


/* Right rotation */

static void right_rotate(tree_t **root, tree_t *y)
{
    tree_t *x;

    x = y->left;

    y->left = x->right;

    if (x->right != NIL)
    {
        x->right->parent = y;
    }

    x->parent = y->parent;

    if (y->parent == NIL)
    {
        *root = x;
    }
    else if (y == y->parent->left)
    {
        y->parent->left = x;
    }
    else
    {
        y->parent->right = x;
    }

    x->right = y;
    y->parent = x;
}


/* Insertion fix-up */

static void insert_fixup(tree_t **root, tree_t *z)
{
    while (z->parent->color == RED)
    {
        tree_t *parent = z->parent;
        tree_t *grandparent = parent->parent;

        if (parent == grandparent->left)
        {
            tree_t *uncle = grandparent->right;

            if (uncle->color == RED)
            {
                parent->color = BLACK;
                uncle->color = BLACK;
                grandparent->color = RED;

                z = grandparent;
            }
            else
            {
                if (z == parent->right)
                {
                    z = parent;

                    left_rotate(root, z);

                    parent = z->parent;
                    grandparent = parent->parent;
                }

                parent->color = BLACK;
                grandparent->color = RED;

                right_rotate(root, grandparent);
            }
        }
        else
        {
            tree_t *uncle = grandparent->left;

            if (uncle->color == RED)
            {
                parent->color = BLACK;
                uncle->color = BLACK;
                grandparent->color = RED;

                z = grandparent;
            }
            else
            {
                if (z == parent->left)
                {
                    z = parent;

                    right_rotate(root, z);

                    parent = z->parent;
                    grandparent = parent->parent;
                }

                parent->color = BLACK;
                grandparent->color = RED;

                left_rotate(root, grandparent);
            }
        }
    }

    (*root)->color = BLACK;
    (*root)->parent = NIL;
}


/* Insert */

int insert(tree_t **root, data_t item)
{
    tree_t *parent;
    tree_t *current;
    tree_t *new_node;

    init_nil();

    parent = NIL;

    if (*root == NULL)
    {
        current = NIL;
    }
    else
    {
        current = *root;
    }

    while (current != NIL)
    {
        parent = current;

        if (item < current->data)
        {
            current = current->left;
        }
        else if (item > current->data)
        {
            current = current->right;
        }
        else
        {
            return FAILURE;
        }
    }

    new_node = create_node(item);

    if (new_node == NULL)
    {
        return FAILURE;
    }

    new_node->parent = parent;

    if (parent == NIL)
    {
        *root = new_node;
    }
    else if (item < parent->data)
    {
        parent->left = new_node;
    }
    else
    {
        parent->right = new_node;
    }

    insert_fixup(root, new_node);

    return SUCCESS;
}


/* Search */

static tree_t *search_node(tree_t *root, data_t item)
{
    while (root != NIL)
    {
        if (item == root->data)
        {
            return root;
        }

        if (item < root->data)
        {
            root = root->left;
        }
        else
        {
            root = root->right;
        }
    }

    return NIL;
}


int search(tree_t **root, data_t item)
{
    init_nil();

    if (root == NULL || is_empty(*root))
    {
        return FAILURE;
    }

    return search_node(*root, item) != NIL
           ? SUCCESS
           : FAILURE;
}


/* Minimum */

static tree_t *minimum_node(tree_t *root)
{
    while (root->left != NIL)
    {
        root = root->left;
    }

    return root;
}


int find_minimum(tree_t **root, data_t *min)
{
    init_nil();

    if (root == NULL ||
        min == NULL ||
        is_empty(*root))
    {
        return FAILURE;
    }

    *min = minimum_node(*root)->data;

    return SUCCESS;
}


/* Maximum */

static tree_t *maximum_node(tree_t *root)
{
    while (root->right != NIL)
    {
        root = root->right;
    }

    return root;
}


int find_maximum(tree_t **root, data_t *max)
{
    init_nil();

    if (root == NULL ||
        max == NULL ||
        is_empty(*root))
    {
        return FAILURE;
    }

    *max = maximum_node(*root)->data;

    return SUCCESS;
}


/* Transplant */

static void transplant(tree_t **root,
                       tree_t *u,
                       tree_t *v)
{
    if (u->parent == NIL)
    {
        *root = v;
    }
    else if (u == u->parent->left)
    {
        u->parent->left = v;
    }
    else
    {
        u->parent->right = v;
    }

    v->parent = u->parent;
}


/* Delete fix-up */

static void delete_fixup(tree_t **root, tree_t *x)
{
    while (x != *root && x->color == BLACK)
    {
        if (x == x->parent->left)
        {
            tree_t *sibling = x->parent->right;

            if (sibling->color == RED)
            {
                sibling->color = BLACK;
                x->parent->color = RED;

                left_rotate(root, x->parent);

                sibling = x->parent->right;
            }

            if (sibling->left->color == BLACK &&
                sibling->right->color == BLACK)
            {
                sibling->color = RED;

                x = x->parent;
            }
            else
            {
                if (sibling->right->color == BLACK)
                {
                    sibling->left->color = BLACK;
                    sibling->color = RED;

                    right_rotate(root, sibling);

                    sibling = x->parent->right;
                }

                sibling->color = x->parent->color;

                x->parent->color = BLACK;

                sibling->right->color = BLACK;

                left_rotate(root, x->parent);

                x = *root;
            }
        }
        else
        {
            tree_t *sibling = x->parent->left;

            if (sibling->color == RED)
            {
                sibling->color = BLACK;
                x->parent->color = RED;

                right_rotate(root, x->parent);

                sibling = x->parent->left;
            }

            if (sibling->right->color == BLACK &&
                sibling->left->color == BLACK)
            {
                sibling->color = RED;

                x = x->parent;
            }
            else
            {
                if (sibling->left->color == BLACK)
                {
                    sibling->right->color = BLACK;
                    sibling->color = RED;

                    left_rotate(root, sibling);

                    sibling = x->parent->left;
                }

                sibling->color = x->parent->color;

                x->parent->color = BLACK;

                sibling->left->color = BLACK;

                right_rotate(root, x->parent);

                x = *root;
            }
        }
    }

    x->color = BLACK;
}


/* Delete */

int delete(tree_t **root, data_t item)
{
    tree_t *z;
    tree_t *y;
    tree_t *x;

    color_t original_color;

    init_nil();

    if (root == NULL || is_empty(*root))
    {
        return FAILURE;
    }

    z = search_node(*root, item);

    if (z == NIL)
    {
        return FAILURE;
    }

    y = z;

    original_color = y->color;

    if (z->left == NIL)
    {
        x = z->right;

        transplant(root, z, z->right);
    }
    else if (z->right == NIL)
    {
        x = z->left;

        transplant(root, z, z->left);
    }
    else
    {
        y = minimum_node(z->right);

        original_color = y->color;

        x = y->right;

        if (y->parent == z)
        {
            x->parent = y;
        }
        else
        {
            transplant(root, y, y->right);

            y->right = z->right;

            y->right->parent = y;
        }

        transplant(root, z, y);

        y->left = z->left;

        y->left->parent = y;

        y->color = z->color;
    }

    free(z);

    if (original_color == BLACK)
    {
        delete_fixup(root, x);
    }

    if (*root != NIL)
    {
        (*root)->parent = NIL;
    }

    return SUCCESS;
}


/* Delete minimum */

int delete_minimum(tree_t **root)
{
    data_t min;

    if (!find_minimum(root, &min))
    {
        return FAILURE;
    }

    return delete(root, min);
}


/* Delete maximum */

int delete_maximum(tree_t **root)
{
    data_t max;

    if (!find_maximum(root, &max))
    {
        return FAILURE;
    }

    return delete(root, max);
}


/* Inorder */

void inorder(tree_t *root)
{
    if (is_empty(root))
    {
        return;
    }

    inorder(root->left);

    printf("%d(%s) ",
           root->data,
           root->color == RED ? "RED" : "BLACK");

    inorder(root->right);
}


/* Preorder */

void preorder(tree_t *root)
{
    if (is_empty(root))
    {
        return;
    }

    printf("%d(%s) ",
           root->data,
           root->color == RED ? "RED" : "BLACK");

    preorder(root->left);

    preorder(root->right);
}


/* Display */

static void display_rec(tree_t *root, int level)
{
    int i;

    if (is_empty(root))
    {
        return;
    }

    display_rec(root->right, level + 1);

    for (i = 0; i < level; i++)
    {
        printf("    ");
    }

    printf("%d[%c]\n",
           root->data,
           root->color == RED ? 'R' : 'B');

    display_rec(root->left, level + 1);
}


void display(tree_t *root)
{
    if (is_empty(root))
    {
        printf("Tree is empty.\n");
        return;
    }

    display_rec(root, 0);
}


/* Free tree */

static void free_rec(tree_t *root)
{
    if (is_empty(root))
    {
        return;
    }

    free_rec(root->left);
    free_rec(root->right);

    free(root);
}


void free_tree(tree_t **root)
{
    init_nil();

    if (root == NULL)
    {
        return;
    }

    free_rec(*root);

    *root = NULL;
}